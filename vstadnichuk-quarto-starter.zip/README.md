# Vladimir Stadnichuk — Quarto website

This repository contains the source for a personal website built with Quarto.

## Main source files

- `index.qmd` — About Me / home page
- `publications.qmd` — Publications
- `talks.qmd` — Talks
- `software.qmd` — Software and projects
- `_quarto.yml` — Global website configuration and navbar
- `styles.css` — Optional custom styling

## Preview locally

Open the project folder in VS Code and run:

```powershell
quarto preview
```

Or use the Quarto **Preview** button in VS Code.

## Build the website

Run:

```powershell
quarto render
```

The generated website will be placed in `docs/`.

Do not manually edit files in `docs/`; edit the `.qmd` source files instead and render again.

## Publishing workflow

1. Edit the `.qmd` files.
2. Preview the website.
3. Run `quarto render`.
4. Commit the changes in GitHub Desktop.
5. Push to GitHub.
6. Configure GitHub Pages to publish from the `main` branch and `/docs` folder.
